library(tidyverse)
library(tidyfinance)
library(tsibble)
library(feasts)
library(tseries)
library(broom)
library(PortfolioAnalytics)
library(rugarch)
library(ggpubr)

n_sim <- 1000

# Define multiple GARCH specifications
volatility_specs <-
  list(
    # sGARCH (Standard GARCH) is the simplest GARCH model that models the conditional variance
    # as a function of past squared residuals and past variances. It is used to capture volatility clustering in financial data.
    sGARCH = ugarchspec(
      variance.model = list(model = "sGARCH", garchOrder = c(1, 0)),
      fixed.pars = c(mu = 0.1, ar1 = 0.9, omega = 0.1, alpha1 = 0.7),
      mean.model = list(armaOrder = c(1, 0)),
      distribution.model = "norm"
    ),
    # gjrGARCH (Glosten-Jagannathan-Runkle GARCH) introduces an asymmetry term to capture the leverage effect,
    # where negative shocks have a larger impact on volatility compared to positive shocks.
    gjrGARCH = ugarchspec(
      variance.model = list(model = "gjrGARCH", garchOrder = c(1, 1)),
      fixed.pars = c(mu = 0.1, ar1 = 0.9, omega = 0.1, alpha1 = 0.5, beta1 = 0.1, gamma1 = 0.1),
      mean.model = list(armaOrder = c(1, 0)),
      distribution.model = "norm"
    ),
    # eGARCH (Exponential GARCH) models the logarithm of the conditional variance,
    # allowing for both asymmetry and capturing the effect of past returns.
    # It ensures that the variance is always positive without imposing non-negativity constraints.
    eGARCH = ugarchspec(
      variance.model = list(model = "eGARCH", garchOrder = c(1, 1)),
      fixed.pars = c(mu = 0.1, ar1 = 0.9, omega = 0.1, alpha1 = 0.5, beta1 = 0.4, gamma1 = 0.1),
      mean.model = list(armaOrder = c(1, 0)),
      distribution.model = "norm"
    ),
    # iGARCH (Integrated GARCH) is a restricted version of GARCH where the persistence of volatility
    # is enforced to be unity, implying long memory behavior in the volatility process.
    iGARCH = ugarchspec(
      variance.model = list(model = "iGARCH", garchOrder = c(1, 1)),
      fixed.pars = c(mu = 0.1, ar1 = 0.9, omega = 0.1, alpha1 = 0.5),
      mean.model = list(armaOrder = c(1, 0)),
      distribution.model = "norm"
    ),
    # apARCH (Asymmetric Power ARCH) allows for asymmetric effects and models the conditional standard deviation
    # to a power 'delta', providing greater flexibility in capturing non-linear relationships in volatility.
    apARCH = ugarchspec(
      variance.model = list(model = "apARCH", garchOrder = c(1, 1)),
      fixed.pars = c(mu = 0.1, ar1 = 0.9, omega = 0.1, alpha1 = 0.5, beta1 = 0.4, gamma1 = 0.1, delta = 1),
      mean.model = list(armaOrder = c(1, 0)),
      distribution.model = "norm"
    )
  )

# Loop through each specification and simulate
sim_data <-
  map(
    names(volatility_specs),
    function(model_name) {
      spec <- volatility_specs[[model_name]]
      simulation <- ugarchpath(spec = spec, n.sim = n_sim)
      tibble(
        time = 1:n_sim,
        series = as.numeric(simulation@path$seriesSim),
        sigma = as.numeric(simulation@path$sigmaSim),
        model = model_name
      )
    }
  ) %>%
  list_rbind()

# Plot the simulations
sim_data %>%
  pivot_longer(c(series, sigma)) %>%
  ggplot(aes(time, value, color = model)) +
  geom_line() +
  facet_wrap(~name, scales = "free", nrow = 2) +
  theme(legend.position = "bottom")

# Display time series diagnostics for each model
plots <-
  sim_data %>%
  group_by(model) %>%
  nest() %>%
  mutate(
    data = map(data, ~ as_tsibble(., index = time)),
    plot = map(data, ~ gg_tsdisplay(., sigma, plot_type = "partial"))
  ) %>%
  ungroup() %>%
  glimpse()

models <- plots %>% pull(model)
for (m in models) {
  print(str_c("Model: ", m))
  plots %>%
    filter(model == m) %>%
    pull(plot) %>%
    print()

  readline("Press enter to continue")
}
